// returns a pseudo random number between a given minimum and maximum range
function randomNumber(min, max) {
	return Math.floor(Math.random() * (max - min) + min);
};

myNumber = randomNumber(1,100);
var turns = 6;

console.log(String("I'm thinking of a number between 1 and 100. If you can guess in 5 tries, you win!"));
var guess = prompt("What number am I thinking of?");

function guessCheck (myNumber, guess, turns){
	if (Number(guess) == Number(myNumber)){
		console.log(String("You win! I was thinking of the number " + myNumber + String(".")));
	} else{
		while (turns > 0){
			if ((guess > 100) || (guess < 1)){
				console.log(String("You entered ") + guess + String(". Please select a number between 1 and 100."))
				guess = prompt("What number am I thinking of?");
			}
			else if (Number(guess) == Number(myNumber)){
				console.log(String("You win! I was thinking of the number " + myNumber + String(".")));
				break;
			} else {
				turns = turns -= 1;
				if (turns > 0){				
					if (guess > myNumber){
						console.log(String("You guessed ") + guess + String(". My number is LOWER than that.") + String("You have ") + turns + String(" more tries."))
						guess = prompt("What number am I thinking of?");
					} else {
						console.log(String("You guessed ") + guess + String(". My number is HIGHER than that.") + String("You have ") + turns + String(" more tries."))
						guess = prompt("What number am I thinking of?");
					};
				} else {
					console.log(String("Sorry, I was thinking of ") + myNumber + String(". You lose."))
				};

			};
		};
	};
};

guessCheck(myNumber, guess, turns);
