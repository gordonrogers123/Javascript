//Dice

function randomNumber(min, max) {
	return Math.floor(Math.random() * (max - min) + min);
};

function rollDice(D4, D6, D12, D20){
	
	const D4rolls = [];
	const D6rolls = [];
	const D12rolls = [];
	const D20rolls = [];
	
	var D4total=0;
	var D6total=0;
	var D12total=0;
	var D20total=0;
	
	for (var arg=0; arg < arguments.length; ++arg){
		
		var arr = arguments[arg];
		
		for (var i=0; i<arr; i++){
			if (arg == 0){
				var roll = randomNumber(1,5);
				D4rolls.push(roll);
			}
			else if (arg == 1){
				var roll = randomNumber(1,7);
				D6rolls.push(roll);
			}
			else if (arg == 2){
				var roll = randomNumber(1,13);
				D12rolls.push(roll);
			}
			else {
				var roll = randomNumber(1,20);
				D20rolls.push(roll);
			};
		};
	};
	
	for (roll in D4rolls){
		D4total = D4total + D4rolls[roll]
	};
	for (roll in D6rolls){
		D6total = D6total + D6rolls[roll]
	};
	for (roll in D12rolls){
		D12total = D12total + D12rolls[roll]
	};
	for (roll in D20rolls){
		D20total = D20total + D20rolls[roll]
	};
	
	
	if (D4rolls.length != 0){
		console.log("D4 rolls:", D4rolls)
		console.log("D4 total:", D4total)
	};

	if (D6rolls.length != 0){
		console.log("D6 rolls:", D6rolls)
		console.log("D6 total:", D6total)
	};
	
	if (D12rolls.length != 0){
		console.log("D12 rolls:", D12rolls)
		console.log("D12 total:", D12total)
	};
	
	if (D20rolls.length != 0){
		console.log("D20 rolls:", D20rolls)
		console.log("D20 total:", D20total)
	};
	
};

D4 = prompt("How many D4 do you want to roll?")
D6 = prompt("How many D6 do you want to roll?")
D12 = prompt("How many D12 do you want to roll?")
D20 = prompt("How many D20 do you want to roll?")

rollDice(D4, D6, D12, D20);
