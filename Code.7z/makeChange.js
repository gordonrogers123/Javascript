var Dollar = 0;
var Quarter = 0;
var Dime = 0;
var Nickle = 0;
var Penny = 0;

function makeChange(cost, money){
	
	cost = cost * 100;
	money = money * 100;
	
	var change = money - cost;
	
	while (change >= 100){
		Dollar += 1;
		change -= 100;
	};
	
	while (change >= 25){
		Quarter += 1;
		change -= 25;
	};
	
	while (change >= 10){
		Dime += 1;
		change -= 10;
	};
	
	while (change >= 5) {
		Nickle += 1;
		change -= 5;
	};
	
	Penny = change;
	
	if (change < 0) {
		console.log("You don't have enough money!");
	}
	
	else (
		console.log(String("Here's your change: "), 
		Dollar, String("Dollars, "), 
		Quarter, String("Quarters, "), 
		Dime, String("Dimes, "), 
		Nickle, String("Nickles, and "), 
		Penny, String("Pennies." ))
	);
};

const cost = prompt("How much does the item cost?");
const money = prompt("How much money do you have?");

makeChange(cost, money);