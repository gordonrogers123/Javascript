var theBoard = {'7': ' ', '8': ' ', '9': ' ', '4': ' ', '5': ' ', '6': ' ', '1': ' ', '2': ' ', '3': ' '};

var board_keys = [];

for (key in theBoard) {
	board_keys.push(key);
};

function printBoard(board){
	console.log(board['7'] + '|' + board['8'] + '|' + board['9']);
	console.log('-+-+-');
	console.log(board['4'] + '|' + board['5'] + '|' + board['6']);
	console.log('-+-+-');
	console.log(board['1'] + '|' + board['2'] + '|' + board['3']);
	console.log('\n');
};

function endGame(){
	return(console.log("\n" + "Thanks for playing. Goodbye!"));
};

function restartGame(){
	theBoard = {'7': ' ', '8': ' ', '9': ' ', '4': ' ', '5': ' ', '6': ' ', '1': ' ', '2': ' ', '3': ' '};
	board_keys = [];
	for (key in theBoard) {
		board_keys.push(key);
		game();
	};
};

function game(){
	
	var turn = 'X';
	var count = 0;
	
	console.log("\n");
	console.log("Let's play Tic Tac Toe.");
	console.log("To play, select the space (numbers 1-9) that you would like to move to.");
	console.log("\n");
	
	while (count < 9){
		console.log(turn + "'s turn:");
		printBoard(theBoard);
		
		var move = prompt("It's your turn, " + turn + ". Move to which place?");
		
		if (move != 1 && move != 2 && move != 3 && move != 4 && move != 5 && move != 6 && move != 7 && move != 8 && move != 9){
			console.log("Please select the space (numbers 1-9) that you would like to move to.");
			continue;
		}  
		if (theBoard[move] == ' '){
			theBoard[move] = turn;
			count +=1;
		} else {
			console.log("That space is already taken. \nMove to which place?");
			continue;
		};
		
		
		if ((theBoard[1] == turn && theBoard[2] == turn && theBoard[3] == turn) || (theBoard[4] == turn && theBoard[5] == turn && theBoard[6] == turn) || (theBoard[7] == turn && theBoard[8] == turn && theBoard[9] == turn)){
			printBoard(theBoard);
			console.log(turn + " wins!");
			break;
		} else if ((theBoard[1] == turn && theBoard[4] == turn && theBoard[7] == turn) || (theBoard[2] == turn && theBoard[5] == turn && theBoard[8] == turn) || (theBoard[3] == turn && theBoard[6] == turn && theBoard[9] == turn)){
			printBoard(theBoard);
			console.log(turn + " wins!");
			break;
		} else if ((theBoard[1] == turn && theBoard[5] == turn && theBoard[9] == turn) || (theBoard[3] == turn && theBoard[5] == turn && theBoard[7] == turn)){
			printBoard(theBoard);
			console.log(turn + " wins!");
			break;
		};
	
		
		if (count == 9){
			printBoard(theBoard);
			console.log("Game Over.");
			console.log("It's a TIE!");
			console.log("\n");
			break;
		};

		if (turn == 'X'){
			turn = 'O'
		} else {
			turn = 'X'
		};
	};
	
	var restart = prompt("Would you like to play again?(y/n)");
	
	if (restart == 'y' || restart == 'Y'){
		restartGame();
	} else {
		endGame();
	};
};

game();

