for(x=1;x<=100;x++){
	if (x%25==0){
		console.log(x, String("Quarter!!"))
	}
	
	else if (x%5==0){
		console.log(x, String("Bizz"))
	}
	
	else if (x%2==0){
		console.log(x, String("Bar"))
	}
	
	else{
		console.log(x, String("Foo"))
	};
};