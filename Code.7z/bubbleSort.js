//Bubble Sort
function bubbleSort(arr){
	
	for (var i=0; i < arr.length; i++){
		
		for (var j=0; j < arr.length-1-i; j++){
			
			if (arr[j] > arr[j+1]){
				var temp = arr[j]
				arr[j] = arr[j+1]
				arr[j+1] = temp 
			};
		};
	};
	return(arr);
};

var arr = [12,43,17,26,4,82,73,62];
console.log("Unsorted Array: ", arr);
console.log("Sorted Array: ", bubbleSort(arr));