function RockPaperScissors(){
	
	var rounds = 3;
	var compScore = 0;
	var playerScore = 0;

	const choices = ['rock', 'paper', 'scissors'];

	console.log("Let's play Rock Paper Scissors. Best of 3 wins!");

	while (rounds > 0) {
		var compChoice = choices[Math.floor(Math.random() * choices.length)];
		var playerChoice = prompt("Choose 1 for Rock, 2 for Paper, or 3 for Scissors.");
		playerChoice = choices[playerChoice - 1];
		
		if (playerChoice != choices[0] && playerChoice != choices[1] && playerChoice != choices[2]){
			playerChoice = prompt("That is not a valid input. Please choose 1 for Rock, 2 for Paper, or 3 for Scissors.");
			playerChoice = choices[playerChoice - 1];
		} else if ((compChoice == choices[0] && playerChoice == choices[0]) || (compChoice == choices[1] && playerChoice == choices[1]) || (compChoice == choices[1] && playerChoice == choices[1])) {
			console.log("The computer chose " + compChoice + ", and you chose " + playerChoice + ". It's a TIE.")
		} else if ((compChoice == choices[0] && playerChoice == choices[2]) || (compChoice == choices[1] && playerChoice == choices[0]) || (compChoice == choices[2] && playerChoice == choices[1])){
			console.log("The computer chose " + compChoice + ", and you chose " + playerChoice + ". The computer wins.")
			compScore += 1;
			rounds -= 1;
		} else {
			console.log("The computer chose " + compChoice + ", and you chose " + playerChoice + ". You win.")
			playerScore += 1;
			rounds -= 1;
		};
	};
	if (compScore > playerScore) {
		console.log("The computer wins " + compScore + " to " + playerScore + ".")
	} else {
		console.log("You win " + playerScore + " to " + compScore + ".")
	};
};

RockPaperScissors();